# Borç Takip Android projesi (ilk sürüm)

PIN yok. Çevrimdışı kullanım. Android SQLite cihaz içi veritabanı.

## İçerik
- Müşteri ekleme ve isim/telefon arama
- Müşteri ad/telefon düzenleme
- Müşteri silme (işlem kayıtları da silinir; onay sorulur)
- Ürün/borç kaydı
- Tahsilat kaydı (borçtan düşer)
- Müşteri işlem geçmişi ve bakiye
- Toplam alacak ve müşteri sayısı
- CSV dışa aktarma (Android dosya seçici ile kaydetme)

## APK derleme
1. Bilgisayara Android Studio kur (Android Developers'ın resmi sitesinden).
2. ZIP'i aç.
3. Android Studio > Open > ZIP içinden çıkan `BorcTakip` klasörünü seç.
4. Gradle senkronizasyonu tamamlanınca Build > Build APK(s) menüsünü seç.
5. APK, `app/build/outputs/apk/debug/app-debug.apk` altında oluşur.

## Tablete yükleme
- APK dosyasını USB kablosuyla tablete kopyala (Downloads klasörü uygun).
- Tablette Dosyalar/Downloads uygulamasında APK'ya dokun.
- Android izin isterse Ayarlar'da "Bu kaynaktan uygulama yüklemeye izin ver" seçeneğini aç.
- Geri dön, Yükle'ye dokun ve aç.

İnternet sadece Android Studio/Gradle ilk derleme ve indirme aşamasında gerekir. Kurulmuş uygulama müşteri kayıtlarını internet olmadan SQLite ile cihazda tutar.

## Veri kaybı hakkında
SQLite verileri uygulama kapatıldığında veya tablet yeniden başlatıldığında kalır. Ancak uygulamayı kaldırmak, uygulama verilerini temizlemek veya tableti fabrika ayarlarına döndürmek veritabanını silebilir. Bu sürüm CSV dışa aktarma içerir; CSV dışa aktarma işlem geçmişini yedekler fakat bu sürümde CSV'den otomatik geri yükleme henüz eklenmedi. Önemli kayıtlar için düzenli CSV dışa aktarımı yapın.

## Build bilgisi
- Kotlin / Android SDK
- Minimum Android 6.0 (API 23)
- compile/target SDK 35
