# CIHAN KİLOLUK SÜNGER – Android (tek cihaz)

Yerel SQLite veritabanı kullanır. Bulut, Firebase, ikinci cihaz senkronizasyonu ve internet bağlantısı gerektirmez.

## Modüller
- Sünger çeşidi/ürün stok listesi, kilogram stok takibi ve kritik stok seviyesi
- Alış kaydı: tedarikçi, kg, kg alış fiyatı, toplam, ödenen; alış stok artırır ve ortalama maliyeti günceller
- Satış kaydı: müşteri, ürün, kg, kg satış fiyatı, toplam, peşin alınan, işlem yapan; satış stok düşürür
- Müşteri alacakları ve tedarikçi borçları özetleri
- Müşteri tahsilatı ve tedarikçi ödemesi
- Günlük/aylık alış-satış raporu ve satışın kaydedilmiş ortalama maliyete göre tahmini kârı
- CSV dışa aktarma


## APK derleme
Android Studio ile `BorcTakip` klasörünü açın. Gradle senkronizasyonundan sonra **Build > Build APK(s)**. APK, `app/build/outputs/apk/debug/app-debug.apk` içinde oluşur.


## Veri
Veriler uygulama içi SQLite veritabanında tutulur. Uygulama kapansa veya cihaz yeniden başlasa da kayıtlar kalır. Uygulama kaldırılırsa veriler silinebilir; düzenli CSV dışa aktarma alın.


## Sınırlama
Bu güncelleme kaynak kod düzeyinde hazırlanmıştır; Android SDK/Gradle derleme ortamı bu çalışma oturumunda bulunmadığından APK derlemesi ve gerçek cihaz testi yapılmamıştır. Önce derleme/test, sonra işletme kayıtlarıyla kullanıma geçilmesi önerilir.
